<?php
require_once 'database.php';
// Créer la session si elle n'existe pas
if (!isset($_SESSION)) {
    session_start();
}

class modelEspeces {
    public static function getHabitatDefinitionParIdAPI($habitatnbr){
            $urlhabitat = "https://taxref.mnhn.fr/api/habitats/$habitatnbr";
            $jsonhabitat = file_get_contents($urlhabitat);
            $reponsehabitat = json_decode($jsonhabitat, true);
            $habitat = $reponsehabitat['definition'] ??= "Non renseigné";
            return $habitat;
    }
    public static function getImageParIdAPI($id){
        $url = "https://taxref.mnhn.fr/api/taxa/$id/media";
        $json = file_get_contents($url);
        $reponseimage = json_decode($json, true);
        $image = $reponseimage["_embedded"]["media"][0]["_links"]["thumbnailFile"]["href"] ??= '../assets/images/unknown/unknownanimal.jpeg';
        return $image;
    }

    public static function getAttributParId($attribut, $id, $interne){
        if($interne == TRUE){
            $query = "SELECT $attribut FROM Especes WHERE id = :id"; 
            $values = array(
                ':id' => $id
            );
            $attribut = database::prepareEtExecute($query, $values);
            return $attribut;
        } else {
            $url = "https://taxref.mnhn.fr/api/taxa/$id";
            $json = file_get_contents($url);
            $reponseattribut = json_decode($json, true);

            if($attribut=='habitat'){
                $habitatnbr = $reponseattribut['habitat'] ??= "Non renseigné";
                return self::getHabitatDefinitionParIdAPI($habitatnbr);
            } else if($attribut=='mediaImage'){
                return self::getImageParIdAPI($id);
            }
            else {
                $attribut = $reponseattribut[$attribut] ??= "Non renseigné";
                return $attribut;
            }
        }
    }
}
?>