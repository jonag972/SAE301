DROP TABLE IF EXISTS Utilisateurs;
DROP TABLE IF EXISTS Historique_Utilisateurs;
DROP TRIGGER IF EXISTS tr_utilisateur_insert;
DROP TRIGGER IF EXISTS tr_utilisateur_update;
DROP TRIGGER IF EXISTS tr_utilisateur_delete;

CREATE TABLE IF NOT EXISTS Utilisateurs (
    id_utilisateur INT PRIMARY KEY AUTO_INCREMENT,
    identifiant_utilisateur VARCHAR (100) UNIQUE,
    mot_de_passe VARCHAR (255),
    email VARCHAR (255) UNIQUE,
    prenom VARCHAR (100),
    nom_de_famille VARCHAR (100),
    age INT,
    pays VARCHAR (255),
    ville VARCHAR (255),
    abonnement VARCHAR (50) DEFAULT 'gratuit',
    role VARCHAR (50) DEFAULT 'lambda'
);

CREATE TABLE IF NOT EXISTS Historique_Utilisateurs (
  id_historique_utilisateur INT PRIMARY KEY AUTO_INCREMENT,
  id_utilisateur INT NOT NULL,
  action VARCHAR (10),  -- Peut être "INSERT", "UPDATE" ou "DELETE"
  date_modification TIMESTAMP,
  colonne_changee VARCHAR (100),  -- Le nom de la colonne modifiée
  ancienne_valeur TEXT,
  nouvelle_valeur TEXT
);


DELIMITER //
CREATE TRIGGER tr_utilisateur_update
AFTER UPDATE ON Utilisateurs
FOR EACH ROW
BEGIN
    IF OLD.prenom <> NEW.prenom THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'prenom', OLD.prenom, NEW.prenom);
    END IF;

    IF OLD.identifiant_utilisateur <> NEW.identifiant_utilisateur THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'identifiant_utilisateur', OLD.identifiant_utilisateur, NEW.identifiant_utilisateur);
    END IF;

    IF OLD.nom_de_famille <> NEW.nom_de_famille THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'nom_de_famille', OLD.nom_de_famille, NEW.nom_de_famille);
    END IF;

    IF OLD.email <> NEW.email THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'email', OLD.email, NEW.email);
    END IF;

    IF OLD.age <> NEW.age THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'age', OLD.age, NEW.age);
    END IF;

    IF OLD.pays <> NEW.pays THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'pays', OLD.pays, NEW.pays);
    END IF;

    IF OLD.ville <> NEW.ville THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'ville', OLD.ville, NEW.ville);
    END IF;

    IF OLD.abonnement <> NEW.abonnement THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'abonnement', OLD.abonnement, NEW.abonnement);
    END IF;

    IF OLD.role <> NEW.role THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'role', OLD.role, NEW.role);
    END IF;

    IF OLD.mot_de_passe <> NEW.mot_de_passe THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'UPDATE', NOW(), 'mot_de_passe', OLD.mot_de_passe, NEW.mot_de_passe);
    END IF;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER tr_utilisateur_insert
AFTER INSERT ON Utilisateurs
FOR EACH ROW
BEGIN
    IF NEW.prenom IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'prenom', '', NEW.prenom);
    END IF;

    IF NEW.identifiant_utilisateur IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'identifiant_utilisateur', '', NEW.identifiant_utilisateur);
    END IF;

    IF NEW.nom_de_famille IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'nom_de_famille', '', NEW.nom_de_famille);
    END IF;

    IF NEW.email IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'email', '', NEW.email);
    END IF;

    IF NEW.age IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'age', '', NEW.age);
    END IF;

    IF NEW.pays IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'pays', '', NEW.pays);
    END IF;

    IF NEW.ville IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'ville', '', NEW.ville);
    END IF;

    IF NEW.abonnement IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'abonnement', '', NEW.abonnement);
    END IF;

    IF NEW.role IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'role', '', NEW.role);
    END IF;

    IF NEW.mot_de_passe IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (NEW.id_utilisateur, 'INSERT', NOW(), 'mot_de_passe', '', NEW.mot_de_passe);
    END IF;
END;
//

DELIMITER //
CREATE TRIGGER tr_utilisateur_delete
AFTER DELETE ON Utilisateurs
FOR EACH ROW
BEGIN
    IF OLD.prenom IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'prenom', OLD.prenom, '');
    END IF;

    IF OLD.identifiant_utilisateur IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'identifiant_utilisateur', OLD.identifiant_utilisateur, '');
    END IF;

    IF OLD.nom_de_famille IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'nom_de_famille', OLD.nom_de_famille, '');
    END IF;

    IF OLD.email IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'email', OLD.email, '');
    END IF;

    IF OLD.age IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'age', OLD.age, '');
    END IF;

    IF OLD.pays IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'pays', OLD.pays, '');
    END IF;

    IF OLD.ville IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'ville', OLD.ville, '');
    END IF;

    IF OLD.abonnement IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'abonnement', OLD.abonnement, '');
    END IF;

    IF OLD.role IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'role', OLD.role, '');
    END IF;

    IF OLD.mot_de_passe IS NOT NULL THEN
        INSERT INTO Historique_Utilisateurs (id_utilisateur, action, date_modification, colonne_changee, ancienne_valeur, nouvelle_valeur)
        VALUES (OLD.id_utilisateur, 'DELETE', NOW(), 'mot_de_passe', OLD.mot_de_passe, '');
    END IF;
END;
//