<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="assets/css/elements/navbar.css">
    <meta charset="utf-8">
</head>
<body>
    <div class="navbar-wrapper">
        <nav id="navbar">
            <ul>
                <li><a href="?action=accueil">Accueil</a></li>
                <li><a href="?action=rechercherEspeces">Espèce</a>
                    <ul>
                        <li><a href="?action=afficherToutesLesEspeces">Afficher toutes les espèces</a></li>
                        <li><a href="?action=rechercherEspeces">Rechercher une espèce</a></li>
                        <li><a href="?action=detailsEspece">Détails d'une espèce</a></li>
                    </ul>
                </li>
                <?php
                // Vérifiez si l'utilisateur est connecté
                if (isset($_SESSION['identifiant_utilisateur'])) {
                    // Vérifiez si l'utilisateur est un administrateur
                    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                        echo '<li><a href="?action=adminOptions">Options d\'administration</a></li>';
                    }
                    // Afficher le nom de l'utilisateur
                    echo '<li><a href="?action=monCompte">' . $_SESSION['identifiant_utilisateur'] . '</a></li>';
                    if (isset($_SESSION['role'])) {
                        echo '<li><a href="?action=deconnexion">Se déconnecter</a></li>';
                    }
                } else {
                    echo '<li><a href="?action=seconnecter">Se connecter</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>
</body>
</html>
