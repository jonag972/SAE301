<html>
<head>
    <title>Modifier mon compte</title>
    <link rel="stylesheet" href="assets/css/stylemodifierCompte.css">
</head>
    <?php include 'views/elements/navbar.php'; ?>
    <?php
    // Vérifiez si l'utilisateur est connecté
    if (!isset($_SESSION['username'])) {
        // Si l'utilisateur n'est pas connecté, redirigez-le vers la page de connexion
        header('Location: routeur.php?action=connexion');
        exit();
    }
    ?>

    <body>
        <h2>Modifier mon compte</h2>
        <form method="post" action="routeur.php?action=modificationCompte">
            <label for="nom_utilisateur">Nom d'utilisateur :</label>
            <input type="text" id="nom_utilisateur" name="nom_utilisateur" value="<?php echo $_SESSION['identifiant_utilisateur']; ?>" readonly><br>

            <br>

            <label for="email">Adresse e-mail :</label>
            <input type="email" id="email" name="email" value="<?php echo $_SESSION['email']; ?>" required><br>

            <br>

            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" value="<?php echo $_SESSION['prenom']; ?>" required><br>

            <br>

            <label for="nom_de_famille">Nom de famille :</label>
            <input type="text" id="nom_de_famille" name="nom_de_famille" value="<?php echo $_SESSION['nom_de_famille']; ?>" required><br>

            <br>

            <label for="age">Âge :</label>
            <input type="number" id="age" name="age" value="<?php echo $_SESSION['age']; ?>" required><br>

            <br>

            <label for="pays">Pays :</label>
            <input type="text" id="pays" name="pays" value="<?php echo $_SESSION['pays']; ?>" required><br>

            <br>

            <label for="abonnement">Abonnement :</label>
            <select name="abonnement" id="abonnement">
                <option value="gratuit" <?php if ($_SESSION['abonnement'] == 'gratuit') echo 'selected'; ?>>Gratuit</option>
                <option value="premium" <?php if ($_SESSION['abonnement'] == 'premium') echo 'selected'; ?>>Premium</option>
            </select><br>

            <br>

            <label for="mot_de_passe">Pour modifier votre compte veuillez confirmer votre mot de passe :</label>
            <input type="password" id="mot_de_passe" name="mot_de_passe" required><br>

            <br>

            <input type="submit" value="Confirmer la modification">
        </form>
        <?php
        // Affichez le message d'erreur (s'il existe)
        if (!empty($messageErreur)) {
            echo '<p><strong>' . $messageErreur . '</strong></p>';
        }
        ?>
    </body>
</html>