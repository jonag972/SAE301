<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des espèces résultantes</title>
</head>
<body>
    <h1>Liste des espèces résultantes</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nom</th>
                <th>Nom scientifique</th>
                <th>Genre</th>
                <th>Famille</th>
                <th>Ordre</th>
                <th>Classe</th>
                <th>Royaume</th>
                <th>Habitat</th>
                <th>Image du Média</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($species["_embedded"]["taxa"] as $specie) : ?>
                <tr>
                    <td><?php echo $specie['id']; ?></td>
                    <td><?php echo $specie['frenchVernacularName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['scientificName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['genusName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['familyName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['orderName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['className'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['kingdomName'] ?? "Non renseigné"; ?></td>
                    <td><?php echo $specie['habitat']; ?></td>
                    <td><?php echo $specie['mediaImage']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Ajoutez ici la pagination si nécessaire -->
    <div class="pagination">
        <?php if ($pageNumber > 1) : ?>
            <a href="<?php echo '?page=species&pageNumber=' . $prevPage; ?>">Page précédente</a>
        <?php endif; ?>

        <?php if (count($species["_embedded"]["taxa"]) == $perPage) : ?>
            <a href="<?php echo '?page=species&pageNumber=' . $nextPage; ?>">Page suivante</a>
        <?php endif; ?>
    </div>

</body>
</html>
