<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="assets/css/rechercherEspeces.css" />
    <script src="assets/js/rechercherEspeces.js"></script>
    <title>Recherche par critères</title>
</head>
<body>
    <h1>Recherche par critères</h1>
    <form action="?action=rechercherEspecesResultats" method="get">
        <strong><label for="taxrefIds">Rechercher par :</label></strong>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByScientificName" value="scientificName" onclick="toggleSearchValueInput('searchByScientificName', 'scientificNames')">
        <label for="searchByScientificName">Nom scientifique</label>
        <input type="text" name="scientificNames[]" id="scientificNames" placeholder="Canis lupus" disabled>
        <br>
        <input type="checkbox" name="frenchVernacularNames" id="frenchVernacularNames" value="1" onclick="toggleSearchValueInput('frenchVernacularNames', 'frenchVernacularNamesSearchValue')">
        <label for="frenchVernacularNames">Nom vernaculaire français :</label>
        <input type="text" name="frenchVernacularNamesSearchValue" id="frenchVernacularNamesSearchValue" placeholder="Loup gris" disabled>
        <br>
        <input type="checkbox" name="englishVernacularNames" id="englishVernacularNames" value="1" onclick="toggleSearchValueInput('englishVernacularNames', 'englishVernacularNamesSearchValue')">
        <label for="englishVernacularNames">Nom vernaculaire anglais :</label>
        <input type="text" name="englishVernacularNamesSearchValue" id="englishVernacularNamesSearchValue" placeholder="Gray wolf" disabled>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByVernacularGroups" value="vernacularGroups" onclick="toggleSearchValueInput('searchByVernacularGroups', 'vernacularGroupsInput')">
        <label for="vernacularGroupsInput">Groupe vernaculaire :</label>
        <input type="text" name="vernacularGroups[]" id="vernacularGroupsInput" placeholder="Carnivores" disabled>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByTaxonomicRanks" value="taxonomicRanks" onclick="toggleSearchValueInput('searchByTaxonomicRanks', 'taxonomicRanksSelect')">
        <label for="taxonomicRanksSelect">Rang taxonomique :</label>
        <select name="taxonomicRanks[]" id="taxonomicRanksSelect" disabled>
            <option value="Dumm">Domaine</option>
            <option value="KD">Règne</option>
            <option value="PH">Phylum</option>
            <option value="CL">Classe</option>
            <option value="OR">Ordre</option>
            <option value="FM">Famille</option>
            <option value="SBFM">Sous-Famille</option>
            <option value="TR">Tribu</option>
            <option value="GN">Genre</option>
            <option value="AGES">Agrégat</option>
            <option value="ES">Espèce</option>
            <option value="SSES">Sous-Espèce</option>
            <option value="NAT">Natio</option>
            <option value="VAR">Variété</option>
            <option value="SVAR">Sous-Variété</option>
            <option value="FO">Forme</option>
            <option value="SSFO">Sous-Forme</option>
            <option value="RACE">Race</option>
            <option value="CAR">Cultivar</option>
            <option value="AB">Abberatio</option>
        </select>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByTaxonomicGroups" value="taxonomicGroups" onclick="toggleSearchValueInput('searchByTaxonomicGroups', 'territoriesSelect')">
        <label for="territoriesSelect">Territoire d'occurence :</label>
        <select name="territories[]" id="territoriesSelect" disabled>
            <option value="fr">France métropolitaine</option>
            <option value="gf">Guyane française</option>
            <option value="gua">Guadeloupe</option>
            <option value="mar">Martinique</option>
            <option value="sm">Saint-Martin</option>
            <option value="sb">Saint-Barthélemy</option>
            <option value="spm">Saint-Pierre-et-Miquelon</option>
            <option value="epa">Îles éparses</option>
            <option value="may">Mayotte</option>
            <option value="reu">Réunion</option>
            <option value="sa">Îles subantarctiques</option>
            <option value="ta">Terre Adélie</option>
            <option value="nc">Nouvelle-Calédonie</option>
            <option value="wf">Wallis et Futuna</option>
            <option value="pf">Polynésie française</option>
            <option value="cli">Clipperton</option>
        </select>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByTerritories" value="territories" onclick="toggleSearchValueInput('searchByTerritories', 'domainSelect')">
        <label for="domainSelect">Domaine :</label>
        <select name="domain" id="domainSelect" disabled>
            <option value="Marin">Marin</option>
            <option value="Continental">Continental</option>
        </select>
        <br>
        <input type="checkbox" name="searchBy[]" id="searchByHabitats" value="habitats" onclick="toggleSearchValueInput('searchByHabitats', 'habitatsSelect')">
        <label for="habitatsSelect">Habitat :</label>
        <select name="habitats[]" id="habitatsSelect" disabled>
            <option value="1">Marin</option>
            <option value="2">Eau douce</option>
            <option value="3">Terrestre</option>
            <option value="4">Marin et eau douce</option>
            <option value="5">Marin et terrestre</option>
            <option value="6">Eau saumâtre</option>
            <option value="7">Continental (terrestre et/ou eau douce)</option>
            <option value="8">Continental (terrestre et eau douce)</option>
        </select>
        <br>
        <input type="submit" value="Rechercher">
    </form>
</body>
</html>