    <?php
    require 'models/modelUtilisateur.php';
    class ControllerUtilisateur {
        public function sinscrire() {
            // Afficher le formulaire d'inscription
            include 'views/utilisateur/sinscrireVue.php';
        }

        public function seconnecter() {
            // Afficher le formulaire de connexion
            include 'views/utilisateur/seconnecterVue.php';
        }

        public function inscription() {
            $messageErreur = ''; // Initialisation de la variable d'erreur
            $identifiant_utilisateur = $_POST['identifiant_utilisateur'];
            $mot_de_passe = $_POST['mot_de_passe'];
            $email = $_POST['email'];
            $prenom = $_POST['prenom'];
            $nom_de_famille = $_POST['nom_de_famille'];
            $age = $_POST['age'];
            $pays = $_POST['pays'];
            $abonnement = $_POST['abonnement'];
            $role = 'lambda'; // Role par défaut
            if (!empty($identifiant_utilisateur) && !empty($mot_de_passe) && !empty($email) && !empty($prenom) && !empty($nom_de_famille) && !empty($age) && !empty($pays)) {
                if (modelUtilisateur::getAttributUtilisateurParIdentifiant('identifiant_utilisateur', $identifiant_utilisateur) == NULL) {
                    $modelUtilisateur = new ModelUtilisateur();
                    $modelUtilisateur->ajouterUtilisateur($identifiant_utilisateur, password_hash($mot_de_passe, PASSWORD_DEFAULT), $email, $prenom, $nom_de_famille, $age, $pays, $abonnement, $role);
                    // Créer la session ou la remplacer si elle existe déjà
                    if (isset($_SESSION)) {
                        session_destroy();
                    }
                    // Rediriger l'utilisateur vers la page de connection
                    header('Location: ?action=seconnecter');
                } 
                else {
                    $messageErreur = "L'identifiant existe déjà. Veuillez en choisir un autre.";
                    include 'views/utilisateur/sinscrireVue.php';
                }
            }else {
                $messageErreur = "Veuillez remplir tous les champs avec l'astérisque.";
                include 'views/utilisateur/sinscrireVue.php';
            }
        }

        public function connexion() {
            if (isset($_SESSION['identifiant_utilisateur'])) {
                // L'utilisateur est déjà connecté, redirigez-le vers la page d'accueil
                header('Location: ?action=accueil');
            }
            $identifiant_utilisateur = $_POST['identifiant_utilisateur'];
            $mot_de_passe = $_POST['mot_de_passe'];
            $mot_de_passe_hash = modelUtilisateur::getAttributUtilisateurParIdentifiant('mot_de_passe', $identifiant_utilisateur);
                if (!empty($identifiant_utilisateur)) { 
                    if (!empty($mot_de_passe)) {
                        if ($identifiant_utilisateur == modelUtilisateur::getAttributUtilisateurParIdentifiant('identifiant_utilisateur', $identifiant_utilisateur)) {
                            // Maintenant qu'on sait que l'utilisateur et le mot de passe existe, on vérifie si le mot de passe est correct
                            if (password_verify($mot_de_passe, $mot_de_passe_hash)) {
                                // Les identifiants sont corrects, connectez l'utilisateur
                                // Créer la session ou la remplacer si elle existe déjà
                                if (isset($_SESSION)) {
                                    session_destroy();
                                }
                                session_start();
                                // Ici, vous devez récupérer toutes les informations de l'utilisateur à partir de la base de données
                                // et les stocker dans la session. Je vais supposer que vous avez une méthode pour cela.
                                $_SESSION['id_utilisateur'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('id_utilisateur', $identifiant_utilisateur);
                                $_SESSION['identifiant_utilisateur'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('identifiant_utilisateur', $identifiant_utilisateur);
                                $_SESSION['email'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('email', $identifiant_utilisateur);
                                $_SESSION['prenom'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('prenom', $identifiant_utilisateur);
                                $_SESSION['nom_de_famille'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('nom_de_famille', $identifiant_utilisateur);
                                $_SESSION['age'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('age', $identifiant_utilisateur);
                                $_SESSION['pays'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('pays', $identifiant_utilisateur);
                                $_SESSION['abonnement'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('abonnement', $identifiant_utilisateur);
                                $_SESSION['role'] = modelUtilisateur::getAttributUtilisateurParIdentifiant('role', $identifiant_utilisateur);
                                header('Location: ?action=accueil');
                            } 
                            else {
                                $messageErreur = "Mot de passe incorrect.";
                                // Afficher la vue avec le message d'erreur
                                include 'views/utilisateur/seconnecterVue.php';
                            }
                        }
                        else {
                            $messageErreur = "Nom d'utilisateur inexistant.";
                            // Afficher la vue avec le message d'erreur
                            include 'views/utilisateur/seconnecterVue.php';
                        }
                    }
                    else {
                    $messageErreur = "Veuillez saisir un mot de passe.";
                    // Afficher la vue avec le message d'erreur
                    include 'views/utilisateur/seconnecterVue.php';
                    }
                }
                else {
                    $messageErreur = "Veuillez saisir un nom d'utilisateur.";
                    // Afficher la vue avec le message d'erreur
                    include 'views/utilisateur/seconnecterVue.php';
                }
        }
    

        public function deconnexion() {
            // Déconnectez l'utilisateur
            session_destroy();
            header('Location: ?action=accueil');
        }

        public function monCompte() {
            // Afficher les informations de l'utilisateur
            include 'views/utilisateur/monCompteVue.php';
        }

        public function modifierCompte() {
            // Afficher le formulaire de modification de compte
            include 'views/utilisateur/modifierCompteVue.php';
        }

        public function modificationCompte(){
            $messageErreur = ''; // Initialisation de la variable d'erreur
        
            if (isset($_POST['identifiant_utilisateur']) && isset($_POST['motDePasse']) && isset($_POST['email']) && isset($_POST['prenom']) && isset($_POST['nom_de_famille']) && isset($_POST['age']) && isset($_POST['pays'])) {
                $identifiant_utilisateur = $_POST['identifiant_utilisateur'];
                $mot_de_passe = $_POST['motDePasse'];
                $email = $_POST['email'];
                $prenom = $_POST['prenom'];
                $nom_de_famille = $_POST['nom_de_famille'];
                $age = $_POST['age'];
                $pays = $_POST['pays'];
                $abonnement = $_POST['abonnement'];
                $role = $_SESSION['role'];
        
                // Utilisez le modèle ModelUtilisateur pour vérifier les identifiants de connexion
                $modelUtilisateur = new ModelUtilisateur();
                $utilisateur = $modelUtilisateur->getUtilisateurParNomUtilisateur($identifiant_utilisateur);
        
                if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
                    // Les identifiants sont corrects, alors on peut modifier les informations de l'utilisateur
                    $modelUtilisateur->modifierUtilisateur($identifiant_utilisateur, $mot_de_passe, $email, $prenom, $nom_de_famille, $age, $pays, $abonnement, $role);
                    header('Location: ?action=monCompte');
                } else {
                    $messageErreur = "Mot de passe incorrect.";
                    // Afficher la vue avec le message d'erreur
                    include 'views/utilisateur/modifierCompteVue.php';
                }
            } else {
                // Afficher la vue avec le message d'erreur
                include 'views/utilisateur/modificationCompteVue.php';
            }
        }
    }        
