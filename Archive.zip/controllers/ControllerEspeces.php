<?php
// Créer la session si elle n'existe pas
if (!isset($_SESSION)) {
    session_start();
}
class ControllerEspeces {
    public function afficherToutesLesEspeces() {
        // Récupérer le numéro de page à partir de l'URL
        if (isset($_GET['page'])) {
            $page = (int) $_GET['page'];
        } else {
            $page = 1; // Valeur par défaut si page n'est pas défini dans l'URL
        }

        // Autres paramètres à gérer depuis l'URL, le cas échéant

        // Gérer la pagination
        $nombreEspecesParPage = 10; // Nombre d'espèces par page
    
        // Utilisez l'API pour récupérer les espèces de la page demandée
        $apiUrl = "https://taxref.mnhn.fr/api/taxa/search?version=16.0&page={$page}&size={$perPage}";
        $speciesData = file_get_contents($apiUrl);
        $species = json_decode($speciesData, true);
    
        // Vérifiez le nombre d'espèces retournées
        $numSpecies = count($species["_embedded"]["taxa"]);
    
        // Vérifier les informations d'habitat et de média pour chaque espèce
        foreach ($species["_embedded"]["taxa"] as &$specie) {
            $specie['habitat'] = "Non renseigné";
    
            if (isset($specie['_links']['habitat'])) {
                $apiUrlHabitats = $specie['_links']['habitat']['href'];
                $speciesDataHabitats = file_get_contents($apiUrlHabitats);
                $speciesHabitats = json_decode($speciesDataHabitats, true);
                $specie['habitat'] = $speciesHabitats['definition'] ?? "Non renseigné";
            }
    
            // Vérifier si l'espèce a une image
            if (isset($specie['mediaImage'])) {
                // L'image existe, pas besoin de chercher une autre image
            } else {
                // Si l'espèce n'a pas d'image, appeler la fonction get_image_url avec le nom scientifique
                $query = $specie['genusName'];
                // Récupérer l'URL de l'image correspondant au nom scientifique
                $ccImageUrl = self::get_image_url($query);
                // Ajouter l'image à $specie
                $specie['mediaImage'] = '<img src="' . $ccImageUrl . '" alt="Image du Média" width="100" height="100" loading="lazy">';
            }
        }
    
        // Charger la vue et passer les données à la vue
        ob_start();
        include 'views/barredenavigation.php';
        $content = include 'views/especes/afficherToutesLesEspecesVue.php';
    }

    public function rechercherEspeces() {
        // Afficher la vue de recherche
        include 'views/barredenavigation.php';
        $content = include 'views/especes/rechercherEspecesVue.php';
    }

    public function rechercherEspecesResultats($params) {
        if (isset($params['page']) && $params['page'] === 'search') {
            if (isset($_GET['search_criteria']) && isset($_GET['search_value'])) {
                $searchCriteria = $_GET['search_criteria'];
                $searchText = $_GET['search_value'];
                $habitat = isset($_GET['habitat']) ? $_GET['habitat'] : '';

                switch ($searchCriteria) {
                    case 'scientificNames':
                        $this->rechercheParNomScientifique($searchText, $habitat);
                        break;
                    case 'frenchVernacularNames':
                        $this->rechercheParNomVernaculaireFrancais($searchText, $habitat);
                        break;
                    case 'englishVernacularNames':
                        $this->rechercheParNomVernaculaireAnglais($searchText, $habitat);
                        break;
                    default:
                        // Afficher la vue de critères de recherche par défaut
                        $content = include 'views/especes/rechercherEspecesVue.php';
                        break;
                }
            } else {
                // Afficher la vue de critères de recherche par défaut
                $content = include 'views/especes/rechercherEspecesVue.php';
            }
        }

        // Charger le layout et passer le contenu à afficher dans le layout
        include 'views/barredenavigation.php';
        $content = include 'views/especes/afficherToutesLesEspecesVue.php';
    }

    // Méthode pour afficher les résultats de la recherche par noms scientifiques
    private function rechercheParNomScientifique($searchText, $habitat) {
        // Effectuez la recherche des espèces par noms scientifiques
        // Utilisez $searchText pour effectuer la recherche
        $apiUrl = "https://taxref.mnhn.fr/api/taxa/search?scientificNames={$searchText}&habitats={$habitat}&page={$page}&size={$perPage}";
        // Récupérez les résultats de la recherche
        $speciesData = file_get_contents($apiUrl);
        $species = json_decode($speciesData, true);
        // Affichez les résultats en utilisant la vue appropriée
        $content = include 'views/resultatEspecesVue.php';
    }

    // Méthode pour afficher les résultats de la recherche par noms vernaculaires français
    private function rechercheParNomVernaculaireFrancais($searchText, $habitat) {
        // Effectuez la recherche des espèces par noms vernaculaires français
        // Utilisez $searchText et $habitat pour effectuer la recherche
        $apiUrl = "https://taxref.mnhn.fr/api/taxa/search?frenchVernacularNames={$searchText}&habitats={$habitat}&page={$page}&size={$perPage}";
        // Récupérez les résultats de la recherche
        $speciesData = file_get_contents($apiUrl);
        $species = json_decode($speciesData, true);
        // Affichez les résultats en utilisant la vue appropriée
        $content = include 'views/resultatEspecesVue.php';
    }

    // Méthode pour afficher les résultats de la recherche par noms vernaculaires anglais
    private function rechercheParNomVernaculaireAnglais($searchText, $habitat) {
        // Effectuez la recherche des espèces par noms vernaculaires anglais
        // Utilisez $searchText et $habitat pour effectuer la recherche
        $apiUrl = "https://taxref.mnhn.fr/api/taxa/search?englishVernacularNames={$searchText}&habitats={$habitat}&page={$page}&size={$perPage}";
        // Récupérez les résultats de la recherche
        $speciesData = file_get_contents($apiUrl);
        $species = json_decode($speciesData, true);
        // Affichez les résultats en utilisant la vue appropriée
        $content = include 'views/resultatEspecesVue.php';
    }

    // Fonction pour rechercher une image pour une espèce donnée
    private function get_image_url($query) {
        // Effectuez la recherche d'image en utilisant l'API Creative Commons
        // Utilisez $query pour effectuer la recherche
        $apiUrl = "https://api.creativecommons.engineering/v1/images?query=" . urlencode($query) . "&page=1&per_page=1";
        // Récupérez les résultats de la recherche
        $imageData = file_get_contents($apiUrl);
        $images = json_decode($imageData, true);
    
        if (!empty($images) && isset($images[0]['url'])) {
            // Si une image est trouvée, retournez l'URL de la première image
            return $images[0]['url'];
        } else {
            // Si aucune image n'est trouvée, retournez une URL d'image par défaut
            return "URL_DE_VOTRE_IMAGE_PAR_DEFAUT"; // Remplacez par votre URL d'image par défaut
        }
    }
}